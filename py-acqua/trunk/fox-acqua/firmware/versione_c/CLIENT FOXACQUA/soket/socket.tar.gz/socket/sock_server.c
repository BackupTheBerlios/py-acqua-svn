/* sock_server.c 

# Copyright (C) 2003 Marco Pagnanini
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License as
# published by the Free Software Foundation; either version 2 of
# the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
# USA

*/

// header file per i socket
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

// altri header
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main()
{
  
   int sd, new_sd;
   socklen_t addrlen;
   int bufsize = 1024;
   char *buffer = (char*) malloc(bufsize);


   /*
    * struttura che contiene l'indirizzo ip del
    * server e la porta a cui il server si mette in ascolto
    * oltre che la famiglia di indirizzi usati
    *
    */

    struct sockaddr_in address;


   /*
    * struttura che conterra' l'indirizzo ip
    * e la porta del client (dopo la chiamata accept,
    * netstat -at dara' l'indirizzo del client e la porta
    * che risultera' essere 32775 o 32777 .....)
    * oltre che la famiglia di indirizzi usati
    *
    */

    struct sockaddr_in client_address;


   // puliamo la console
   system("clear");


   /*
    * creiamo il socket come in sock_client.c
    * arg1: AF_INET rappresenta il protocollo ARPA di internet
    *       (AF_INET = IPv4 internet protocol, IP e porta)
    * arg2: sock_stream fornisce una connessione affidabile, sequenziata,
    *       full duplex, dunque una connessione tcp
    * arg3: rappresenta il protocollo, il valore zero permette al sistema di
    *       scegliere quello piu' adatto
    *
    */


   if ((sd = socket(AF_INET,SOCK_STREAM,0)) > 0)
     printf("Socket creato !\n");

   /*
    * come per client ( vedere ip(7) )
    *
    */

   address.sin_family = AF_INET; // famiglia indirizzi ARPA di internet
   address.sin_addr.s_addr = INADDR_ANY; // qualsiasi indirizzo per il binding
   address.sin_port = htons(15000); // numero di porta ascolto server


   /*
    * Associamo un processo al socket locale che rimarra' in attesa
    * delle connessioni da parte di ogni client sulla porta 15000
    * arg1: il desrittore di socket sd creato in precedenza
    * arg2: la struttura address che contiene porta del server e indirizzo ip
    *       del server
    * arg3: dimensione della struttura address
    *
    */

   if ( bind(sd, (struct sockaddr *)&address, sizeof(address)) == 0 )
     printf("Processo per il socket creato ! \n");


   /*
    * mettiamo il processo server appena creato in attesa di eventuali
    * connessioni sul socket
    * arg1: desrittore di socket
    * arg2: grandezza massima della coda delle connessioni vale a dire
    *       numero max di connessioni che possono essere accodate per
    *       una eventuale accept successiva
    *
    */

   listen(sd, 3);


   /*
    * La accept (utilizzata solo con socket connessi come SOCK_STREAM che
    * abbiamo qui utilizzato), prende la prima connessione accodata, crea un
    * nuovosocket new_sd connesso con le stesse propriet� di sd ma con i
    * dati del client e collega i due socket. new_sd viene ritornato da
    * accept. Il server poi comunica con il client leggendo e scrivendo sul
    * socket new_sd .
    * arg1: sd e' il descrittore di socket generato dalla chiamata socket
    *       all' interno del client
    * arg2: l'indirizzo e' quello del server al quale il client deve
    *       connettersi
    *
    */

   // addrlen mi serve poi nella accept
   addrlen = sizeof(struct sockaddr_in);

   // client_address viene riempita con i dati del client
   new_sd = accept(sd, (struct sockaddr *)&client_address, &addrlen);

   if (new_sd > 0)  // non si sono verificati errori
     {
      printf("%s e' connesso ...\n", inet_ntoa(client_address.sin_addr));
      putchar(7); // bell
      }
   else
      return 1;

   while(1)
   {
      printf("Messaggio da inviare: ");
      fgets(buffer, bufsize, stdin);
      if( ! strcmp(buffer, "quit\n") ) //usare quit per uscire
      {
          printf("\n\nUscita\n\n\a");
	  return 0;
      }

      /*
       * trasmissione e ricezione allo stesso modo di sock_client
       *
       */

      send(new_sd, buffer, bufsize, 0);
      recv(new_sd, buffer, bufsize, 0);

      printf("Messaggio ricevuto: %s\n", buffer);
    }

   close(new_sd);		// chiusura di entrambi i socket
   close(sd);

   return 0;
}

